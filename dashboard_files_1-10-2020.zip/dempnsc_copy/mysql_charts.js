//prints viewport width/height, unrelated to the rest of the code.
var w = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
var h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);

console.log(w, h)

//2d array that holds html data from the canvas tags with id "mychartx"
var html_data = [];

//String that will be sent to PHP script to run MySQL query.
var sql_string = "Sensor, ";

//matches is a NodeList of all html elements with an id starting with "mychart"
var matches = document.querySelectorAll("[id^='mychart']");

//position of pm2.5 and pm1.0 data in sql_string, used in the create_charts function
var pm25_index = 1;
var pm1_index = 1;

//each element of html data has this format ["mychart14", "daily", "106,146,215", "Time", "`PM2.5`", "P5_Rupa_Rohi_NA_Dhak_PA", "PurpleAir", "last_30"]
for (i=0; i<matches.length; i++){
	html_data.push([matches[i].id, 
					matches[i].dataset.avg,
					matches[i].dataset.rgb,
					matches[i].dataset.xvar,
					matches[i].dataset.yvar,
					matches[i].dataset.site,
					matches[i].dataset.sensor,
					matches[i].dataset.timeframe,
					matches[i].dataset.charttype
					]);

	//adds ith x variable to sql_string if it's not already there
	if (sql_string.search(html_data[i][3]) === -1){
		sql_string += html_data[i][3] + ", ";
	}

	//adds ith y variable to sql_string if it's not already there
	if (sql_string.search(html_data[i][4]) === -1){
		sql_string += html_data[i][4] + ", ";
		
		//determines order of pm2.5 and pm1.0 in sql_string, used in create_charts function to alternate between the two
		if (html_data[i][4] === "`PM2.5`" && pm25_index === 1){
		    //if pm2.5 is first, pm25_index = 2, otherwise 3
		    pm25_index = pm1_index + 1;
		} 
		else if (html_data[i][4] === "`PM1.0`" && pm1_index === 1){
		    pm1_index = pm25_index + 1; 
		}
	}
}

//removes last , from sql_string
sql_string = sql_string.substring(0, sql_string.length - 2);

//Currently can only use 1 sensor type per page, whichever is in the first element of html_data - will eventually fix this
sql_string += " FROM " + html_data[0][6] + " WHERE entry_id % 10 = 0";

console.log(sql_string);

//this gets the output from the php script that queries the database w/ sql_string, and then passes that output to the create_charts function
$.post('get_sql_data_2.php', {vars: sql_string}, function (data) {
    create_charts(data);
});

//loops through html_data, creates a chart for each element using sql_data
function create_charts(sql_data){
	//converts JSON data to a 2d array - index [j][0] is the jth time stamp, [j][1] is pm2.5, [j][2] is the site name
    var json_data = JSON.parse(sql_data);

    for (i=0; i<html_data.length; i++){
        var pm_index;
        
		var time_array = [];
		var data_array = [];
		
		var point_color_array = [];
		var point_size_array = [];

    	ctx = document.getElementById(html_data[i][0]).getContext('2d');
        
        //pm1.0 data should be in the third column, so pm_index is changed to 2. This is used in the below for loop to push to data_array
        if (html_data[i][4] === "`PM2.5`"){
            pm_index = pm25_index;
        }
        else if (html_data[i][4] === "`PM1.0`"){
            pm_index = pm1_index;
        }
        
    	//creates time and data arrays for each graph by filtering based on site (html_data[i][5])
    	for(j=0; j<json_data.length; j++){
        	if (json_data[j][0] == html_data[i][5]){
        		time_array.push(json_data[j][1]);
        		data_array.push(json_data[j][pm_index]);
        	}
        }
        
        //switches between line and doughnut chart code, based on the value given in the charttype field, data-charttype="line"
        switch(html_data[i][8]){
            case "line":
                //Uses the last n days of data, where n is entered into the timeframe field of the chart canvas tags, ie data-timeframe="30". Use "all" for all data
                if (html_data[i][7] != "all"){
                    [time_array, data_array] = last_n_days(time_array, data_array, parseInt(html_data[i][7]));
                }
                
                //averages data
                [time_array, data_array] = average_data(time_array, data_array, html_data[i][1]);
                
                //fills missing data
                [time_array, data_array] = fill_missing_data(time_array, data_array);
                
                //replaces 0 values (missing data points) with linearly extrapolated values
                [data_array, point_radius] = extrapolate_data(data_array);
                
                console.log(point_radius);
                
                if (html_data[i][2] != "gradient"){
                    create_line_chart(time_array, data_array, html_data[i][2], html_data[i][5]);
                }
                else{
                    create_line_chart(time_array, data_array, create_gradient(data_array), html_data[i][5], point_radius);
                }
                
                break;
                
            case "doughnut":
                //creates doughnut chart
                create_doughnut_chart(time_array, data_array);
                break;
        }
    }
}

function create_line_chart(time_array, data_array, rgb, site, point_radius){
	return new Chart(ctx,{
        type:'line',
        data: {
            labels: time_array,
            datasets: [
            	{
                label: "Raw PM2.5",
                data: data_array,
                backgroundColor: "rgba(0,0,0,0)",
                borderColor: rgb,
                borderWidth: 3,
                pointRadius: point_radius,
                pointBackgroundColor: "black",
                pointBorderColor: "black"
            }]
        },
        options: {
            maintainAspectRatio:false,
            legend: {
                position: 'bottom',
                display: false,
                maintainAspectRatio: false
            },
            tooltips: {
                enabled: true,
                mode: 'nearest',
                intersect: false,
                displayColors: false,
                callbacks: {
                    title: function(tooltipItem, data){
                        return "Date: " + time_array[tooltipItem[0]["index"]];
                    },
                    label: function(tooltipItem, data){
                        return "PM2.5: " + tooltipItem.yLabel + " μg/m^3";
                    }
                }
            },
            elements: {
                center: {
                    text: ""
                }  
            },
            scales: {
                yAxes: [{
                    ticks: {
                        fontFamily: "verdana",
                        beginAtZero:true
                    },
                    gridLines: {
                        display: true
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'PM2.5 (micrograms per cubic meter)',
                        fontSize: 15,
                        fontFamily: "verdana"
                    }
                }],
                xAxes: [{
                    gridLines: {
                        display: true
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Date (mm/dd/yy)',
                        fontSize: 15,
                        fontFamily: "verdana"
                    },
                    ticks: {
                        fontFamily: "verdana",
                        beginAtZero:true,
                        autoSkip: true,
                        maxTicksLimit: 10,
                        maxRotation: 0
                    }
                }]
            }
        }
    });
}

//returns the daily or hourly average of data_array, along with shortened corresponding timestamps, returns the input time/data arrays with shortened timestamps if dailyhourly = "raw" 
function average_data(time_array, data_array, dailyhourly){
	var avg_time_array = [];
	var avg_data_array = [];

	var values_to_average = [];

	//character indexes used to extract day or hour value from the timestamp. Ex: 0,10 gets the 0th through 9th characters, which gets up to the day value
	var char1, char2;

	//Timestamps look like this: "2019-04-25 07:37:34"
	switch (dailyhourly){
		case "raw":
			return [reduce_timestamps(time_array), data_array];
			
        case "daily":
            [char1,char2] = [0,10];
            break;
            
        case "hourly":
            [char1,char2] = [0,13];
            break;
    }
    
    var current_time = time_array[0].substring(char1, char2);

    for (k=0; k<time_array.length; k++){
    	if (time_array[k].substring(char1, char2) == current_time){
    		values_to_average.push(parseInt(data_array[k]));
    	}
    	else{
    		avg_data_array.push(parseInt(values_to_average.reduce(sum_of_array) / values_to_average.length));
    		avg_time_array.push(current_time);

    		values_to_average = [parseInt(data_array[k])];
    		current_time = time_array[k].substring(char1, char2);
    	}
    }

    return [reduce_timestamps(avg_time_array), avg_data_array];
}

//used with reduce function to sum elements of an array, used in the average_data function
function sum_of_array(sum, num){
	return sum + num;
}

//fills in missing timestamps and assigns pm2.5 value of 0. Takes the mm/dd/yy format dates that are output by the average_data function.
function fill_missing_data(time_array, data_array){
    //These are the timestamp strings
	var previous_day = time_array[0];
	var missing_day = "";
	
	//These are the integer day values
	var curr_val;
	var prev_val;
    
	for (h=1; h<time_array.length; h++){
	    curr_val = parseInt(time_array[h].substring(3,5));
	    prev_val = parseInt(previous_day.substring(3,5));
	    
	    //currently assumes 30 days in every month, will probably be a lot of work to fix?
	    if (curr_val != prev_val + 1 && prev_val < 30){
	        missing_day = previous_day.replace(prev_val.toString(), (prev_val + 1).toString())
	        
	        time_array.splice(h, 0, missing_day);
	        data_array.splice(h, 0, 0);
	        previous_day = missing_day;
	    }
	    else{
	        previous_day = time_array[h];
	    }
    }

	return [time_array, data_array];
}

//replaces data values of 0 (inserted by fill_missing_data) with linearly extrapolated values. Also returns an array of data marker sizes, 1 if data was missing, 0 otherwise. 
function extrapolate_data(data_array){
    var z_count = 0;
    var step_size;
    
    var point_radius = [0];
    
    //starts at index 1, so if the first value in the array is 0, it will stay 0
    for (q=1; q<data_array.length; q++){
        if (data_array[q] === 0){
            z_count += 1;
            point_radius.push(2);
        }
        else if (z_count !== 0){
            step_size = (data_array[q] - data_array[q - z_count - 1]) / (z_count + 1);
            
            for (b=0; b<z_count; b++){
                data_array[q - (z_count - b)] = data_array[q - (z_count - b) - 1] + step_size;
            }
            
            z_count = 0;
            point_radius.push(0);
        }
        else{
            point_radius.push(0);
        }
    }
    
    return [data_array, point_radius];
}

//shortens timestamps to be more readable for axis labels
function reduce_timestamps(time_array){
    var time_array_r = [];
    
    for (h=0; h<time_array.length; h++){
        time_array_r[h] = time_array[h].substring(5, 7) + "/" + time_array[h].substring(8, 10) + "/" + time_array[h].substring(2, 4);
    }
    
    return time_array_r;
}

//Takes raw time/data arrays as input, returns time/data arrays for up to the last n days, given in the timeframe parameter
function last_n_days(time_array, data_array, timeframe){
    var time_array_n = [];
    var data_array_n = [];
    
    var index = time_array.length - 1;
    var current_time = time_array[index].substring(0,10);
    
    var n_days = 0;
    
    for (n=index; n>0; n--){
        if (n_days >= timeframe){
            return [time_array_n.reverse(), data_array_n.reverse()];
        }
        else if (time_array[n].substring(0,10) == current_time){
            time_array_n.push(time_array[n].substring(0,10));
            data_array_n.push(data_array[n]);
        }
        else{
            time_array_n.push(time_array[n].substring(0,10));
            data_array_n.push(data_array[n]);
            
            current_time = time_array[n].substring(0,10);
            n_days++;
        }
    }
    
    //The arrays get reversed since the above for loop iterates through time_array from end to start
    return [time_array_n.reverse(), data_array_n.reverse()];
}

//Creates a donut chart with a single value shown in the middle - this is for displaying current pm2.5
function create_doughnut_chart(time_array, data_array){
    //last pm2.5 value in data_array
    var index = time_array.length - 1;
    var pm25_value = data_array[index];
    
    //Last updated text, uses timestamp corresponding to pm25_value
    document.getElementById("doughnut-subtext").innerHTML = "Last updated: " + time_array[index];
    
    //These determine the size of the two areas in the doughnut plot, must add to 100. 500 is the maximum pm2.5 value.
    var doughnut_val_1 = (pm25_value / 500) * 100;
    var doughnut_val_2 = 100 - doughnut_val_1;
    
    //color used for 1 area of the doughnut chart
    var color_1;
    var color_2 = "#d8dfe4";
    
    //Determines color based on pm25_value
    if (pm25_value < 100){
        color_1 = "rgba(56,160,51)";
    }
    else if (pm25_value < 200){
        color_1 = "yellow";
    }
    else{
        color_1 = "rgba(220,19,61)";
    }
    
    var data = {
        labels: ["", ""],
        datasets: [{
            data: [doughnut_val_1, doughnut_val_2],
            backgroundColor: [
                color_1,
                color_2
            ],
            borderColor: [
                color_1,
                color_2
            ],
            hoverBackgroundColor: [
                color_1,
                color_2
            ],
            hoverBorderColor: [
                color_1,
                color_2
            ]
        }]
    };
    
    var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
      	    responsive: true,
            legend: {
                display: false
            },
            cutoutPercentage: 80,
            elements: {
                center: {
                    text: pm25_value,
                    backgroundColor: "white"
                }  
            },
            tooltipTemplate: "<%= value %>",
            onAnimationComplete: function(){
                this.showTooltip(this.segments, true);
            },
            tooltipEvents: [],
            showTooltips: true
        }
    });
    
    //This was mostly copied from a StackOverflow thread, is used to center text in the middle of the doughnut chart
    Chart.pluginService.register({
        beforeDraw: function (chart) {
            var width = chart.chart.width,
                height = chart.chart.height,
                ctx = chart.chart.ctx;
                
            ctx.restore();
            
            var fontSize = (height / 114).toFixed(2);
            
            ctx.font = fontSize + "em verdana";
            ctx.textBaseline = "middle";
            
            var text = chart.config.options.elements.center.text,
                textX = Math.round((width - ctx.measureText(text).width) / 2),
                textY = height / 2;
            
            ctx.fillStyle = color_1;
            ctx.fillText(text, textX, textY);
            ctx.save();
        }
    });
        
    return myChart;
}

//Returns a gradient based on the max value in data_array.
function create_gradient(data_array){
    var pm25_gradient = ctx.createLinearGradient(0, 0, 0, 500);
    
    //green #00e400
    pm25_gradient.addColorStop(0, "#7e0023");
    pm25_gradient.addColorStop(0.08, "#7e0023");
    
    //yellow #cccc00
    pm25_gradient.addColorStop(0.12, "#8f3f97");
    pm25_gradient.addColorStop(0.18, "#8f3f97");
    
    //orange #ff7e00
    pm25_gradient.addColorStop(0.22, "#ff0000");
    pm25_gradient.addColorStop(0.28, "#ff0000");
    
    //red #ff0000
    pm25_gradient.addColorStop(0.32, "#ff7e00");
    pm25_gradient.addColorStop(0.38, "#ff7e00");
    
    //purple #8f3f97
    pm25_gradient.addColorStop(0.42, "#cccc00");
    pm25_gradient.addColorStop(0.58, "#cccc00");
    
    //maroon #7e0023
    pm25_gradient.addColorStop(0.62, "#00e400");
    pm25_gradient.addColorStop(1, "#00e400");
    
    return pm25_gradient;
}

//Returns the maximum value of an array. Wanted to avoid using Math.max() to reduce number of js files that need to be included in the html. 
function array_max(arr) {
    var len = arr.length, max = -Infinity;
    
    while (len--) {
        if (arr[len] > max) {
          max = arr[len];
        }
    }
    
    return max;
};
























