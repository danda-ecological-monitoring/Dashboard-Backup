//*********************************************************************
//global variables
//*********************************************************************

//empty arrays that will store attributes from the html canvas tags
var id_array = [];
var avg_array = [];
var rgb_array = [];
var vars_array = [];
var yvar_array = [];
var sensor_array = [];
var site_array = [];

//empty arrays that will store raw timestamp, pm2.5 data
var time_array = [];
var pm25_array = [];
var site_data_array = [];

//this will contain multiple Chart objects
var objects = {};

//string that will be sent to PHP for MySQL query
var sql_string = "";


//*********************************************************************
//Getting attributes from html canvas tags
//*********************************************************************

//matches is a NodeList of all html canvas elements
var matches = document.querySelectorAll("[id^='mychart']");

//this gets the attributes of each canvas element from matches and puts them in arrays
for (i=0; i<matches.length; i++){
    id_array.push(matches[i].id);
    avg_array.push(matches[i].dataset.avg);
    rgb_array.push(matches[i].dataset.rgb);
    yvar_array.push(matches[i].dataset.yvar);
    site_array.push(matches[i].dataset.site);
    vars_array.push([matches[i].dataset.xvar, yvar_array[i]]);
    
    
    //adding vars to sql_string if they're not already there, ie if search function returns -1
    for (j=0; j<vars_array[i].length; j++){
        if (sql_string.search(vars_array[i][j]) === -1){
            sql_string += vars_array[i][j] + ", ";
        }
    }
}

sql_string += "Sensor FROM " + matches[0].dataset.sensor + " WHERE entry_id % 10 = 0";


//*********************************************************************
//Getting MySQL data from php w/ jQuery, calling create_charts function
//*********************************************************************

//this gets the output from the php script that queries the database w/ sql_string, and then passes that output to the create_charts function
$.post('get_sql_data_2.php', {vars: sql_string}, function (data) {
    create_charts(data);
});

//*********************************************************************
//create_charts and dh_average functions
//*********************************************************************

//this function takes JSON data as a parameter and creates graphs for each html canvas tag
function create_charts(sql_data){
    //converts JSON data to a 2d array of timestamps and pm2.5 vals
    var json_data = JSON.parse(sql_data);
    
    //separates the raw JSON data into 2 arrays
    for(var i in json_data){
    	time_array.push(json_data[i][0]);
    	pm25_array.push(parseInt(json_data[i][1]));
    	site_data_array.push(json_data[i][2])
    }
    
    //these variables are used for creating charts in the below for loop
    var ctx;
    var label;
    var label_array = [];
    var data_array = [];
    var ind;
    
    //creates a Chart object for each id in id_array
    for (i=0; i<id_array.length; i++){
        ctx = document.getElementById(id_array[i]).getContext('2d');
        ind = i;
        
        var time_array_site = [];
        var pm25_array_site = [];

        for(k=0; k<site_data_array.length; k++){
        	if (site_data_array[k] == site_array[i]) {
        		time_array_site.push(time_array[k]);
        		pm25_array_site.push(pm25_array[k]);
        	}
        }
        
        console.log(time_array_site);
        console.log(pm25_array_site);
        
        //this handles the different cases for raw/daily/hourly
        switch (avg_array[i]){
            case "raw":
                label_array = clean_labels(time_array_site);
                data_array = pm25_array_site;
                label = "Raw PM2.5";
                break;
            case "hourly":
                [label_array, data_array] = dh_average(time_array_site, pm25_array_site, avg_array[i]);
                label_array = clean_labels(label_array);
                label = "Hourly PM2.5";
                break;
            case "daily":
                [label_array, data_array] = dh_average(time_array_site, pm25_array_site, avg_array[i]);
                label_array = clean_labels(label_array);
                label = "Daily PM2.5";
                break;
        }
        
        objects[i] = new Chart(ctx,{
            type:'line',
            data: {
                labels: label_array,
                datasets: [
                	{
                    label: label,
                    data: data_array,
                    backgroundColor: "rgba(" + rgb_array[i] + ",0)",
                    borderColor: "rgba(" + rgb_array[i] + ",1)",
                    borderWidth: 3
                }]
            },
            options: {
                maintainAspectRatio:false,
                legend: {
                    position: 'bottom',
                    display: false,
                    maintainAspectRatio: false
                },
                tooltips: {
                    enabled: true,
                    mode: 'nearest',
                    intersect: false,
                    displayColors: false,
                    callbacks: {
                        title: function(tooltipItem, data){
                            return "Timestamp: " + time_array_site[tooltipItem[0]["index"]] + "\nSensor: " + site_data_array[tooltipItem[0]["index"]];
                        },
                        label: function(tooltipItem, data){
                            return yvar_array[ind].replace(/`/g, '') + ": " + tooltipItem.yLabel;
                        }
                    }
                },
                elements: {
                    point:{
                        radius: 0
                    }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true
                        },
                        gridLines: {
                            display: true
                        },
                        scaleLabel: {
                            display: true,
                            labelString: 'PM2.5, micrograms per cubic meter'
                        }
                    }],
                    xAxes: [{
                        gridLines: {
                            display: true
                        },
                        scaleLabel: {
                            display: false,
                            labelString: 'Time'
                        }
                    }]
                }
            }
        });
    }
}

//this function calculates daily or hourly averages and corresponding timestamps and returns them in arrays
function dh_average(time_array, pm25_array, dailyhourly){
    var avg_time_array = [];
    var pm25_avg_array = [];
    
    //start and stop points to be used in the substring function
    var c1,c2;
    
    switch (dailyhourly){
        case "daily":
            [c1,c2] = [8,10];
            break;
        case "hourly":
            [c1,c2] = [11,13];
            break;
    }
    
    var temp = parseInt(time_array[0].substring(c1,c2));
    var avg = 0;
    var count = 0;
    
    for(var i in time_array){
        if ((parseInt(time_array[i].substring(c1,c2)) == temp) && (i < time_array.length - 1)){
            avg += parseInt(pm25_array[i]);
            ++count;
        }
        else{
            avg /= count;
            
            pm25_avg_array.push(parseInt(avg));
            avg_time_array.push(time_array[i-1]);
            
            temp = parseInt(time_array[i].substring(c1,c2));
            avg = parseInt(pm25_array[i]);
            count = 0;
        }
    }
    
    return [avg_time_array, pm25_avg_array];
}

function clean_labels(time_arr){
    var cleaned_labels = [];
    
    for (i=0; i<time_arr.length; i++){
        cleaned_labels[i] = time_arr[i].substring(5,7) + "-" + time_arr[i].substring(8,10);
    }
    
    return cleaned_labels;
}





