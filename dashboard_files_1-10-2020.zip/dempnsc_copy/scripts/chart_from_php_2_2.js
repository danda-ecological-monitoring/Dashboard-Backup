//*********************************************************************
//global variables
//*********************************************************************

//empty arrays that will store attributes from the html canvas tags
id_array = [];
avg_array = [];
rgb_array = [];
vars_array = [];
yvar_array = [];
sensor_array = [];
site_array = [];

//empty arrays that will store raw timestamp, pm2.5 data
time_array = [];
pm25_array = [];

//this will contain multiple Chart objects
objects = {};

//string that will be sent to PHP for MySQL query
sql_string = "";


//*********************************************************************
//Getting attributes from html canvas tags
//*********************************************************************

//matches is a NodeList of all html canvas elements
matches = document.querySelectorAll("[id^='mychart']");

//this gets the attributes of each canvas element from matches and puts them in arrays
for (i=0; i<matches.length; i++){
    id_array.push(matches[i].id);
    avg_array.push(matches[i].dataset.avg);
    rgb_array.push(matches[i].dataset.rgb);
    site_array.push(matches[i].dataset.site)
    yvar_array.push(matches[i].dataset.yvar);
    vars_array.push([matches[i].dataset.xvar, yvar_array[i]]);
    
    
    //adding vars to sql_string if they're not already there, ie if search function returns -1
    for (j=0; j<vars_array[i].length; j++){
        if (sql_string.search(vars_array[i][j]) === -1){
            sql_string += vars_array[i][j] + ", ";
        }
    }
}

//remove the last ", " from the end of sql_string
sql_string = sql_string.slice(0,-2);
sql_string += " FROM " + matches[0].dataset.sensor;


//*********************************************************************
//Getting MySQL data from php w/ jQuery, calling create_charts function
//*********************************************************************

$.each(id_array, function(i){
    site_sql_string = sql_string;
    id = this;
    
    site_sql_string += " WHERE Sensor = \'" + id + "\' AND entry_id % 100 = 0";
    console.log(site_sql_string)
    
    //this gets the output from the php script that queries the database w/ sql_string, and then passes that output to the create_charts function
    $.post('get_sql_data_2.php', {vars: site_sql_string}, function (data) {
        objects[i] = create_charts(data, id, avg_array[i], rgb_array[i], i);
    });
});

//*********************************************************************
//create_charts and dh_average functions
//*********************************************************************

//this function takes JSON data as a parameter and creates graphs for each html canvas tag
function create_charts(sql_data, id, avg, rgb, ind){
    //converts JSON data to a 2d array of timestamps and pm2.5 vals
    var json_data = JSON.parse(sql_data);
    
    //separates the raw JSON data into 2 arrays
    for(var i in json_data){
    	time_array.push(json_data[i][0]);
    	pm25_array.push(parseInt(json_data[i][1]));
    }
    
    //these variables are used for creating charts in the below for loop
    var ctx;
    var label;
    var label_array = [];
    var data_array = [];
    
    //creates a Chart object for each id in id_array
    console.log(id)
    ctx = document.getElementById(id).getContext('2d');
    
    //this handles the different cases for raw/daily/hourly
    switch (avg){
        case "raw":
            label_array = clean_labels(time_array);
            data_array = pm25_array;
            label = "Raw PM2.5";
            break;
        case "hourly":
            [label_array, data_array] = dh_average(time_array, pm25_array, avg_array[i]);
            label_array = clean_labels(label_array);
            label = "Hourly PM2.5";
            break;
        case "daily":
            [label_array, data_array] = dh_average(time_array, pm25_array, avg_array[i]);
            label_array = clean_labels(label_array);
            label = "Daily PM2.5";
            break;
    }
    
    object = new Chart(ctx,{
        type:'line',
        data: {
            labels: label_array,
            datasets: [
            	{
                label: label,
                data: data_array,
                backgroundColor: "rgba(" + rgb + ",0)",
                borderColor: "rgba(" + rgb + ",1)",
                borderWidth: 3
            }]
        },
        options: {
            maintainAspectRatio:false,
            legend: {
                position: 'right',
                display: false,
                maintainAspectRatio: false
            },
            tooltips: {
                enabled: true,
                mode: 'nearest',
                intersect: false,
                displayColors: false,
                callbacks: {
                    title: function(tooltipItem, data){
                        return "Timestamp: " + time_array[tooltipItem[0]["index"]];
                    },
                    label: function(tooltipItem, data){
                        return yvar_array[ind].replace(/`/g, '') + ": " + tooltipItem.yLabel;
                    }
                }
            },
            elements: {
                point:{
                    radius: 0
                }
            },
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }],
                xAxes: [{
                    gridLines: {
                        display: false
                    }
                }]
            }
        }
    });
    
    return object;
}

//this function calculates daily or hourly averages and corresponding timestamps and returns them in arrays
function dh_average(time_array, pm25_array, dailyhourly){
    var avg_time_array = [];
    var pm25_avg_array = [];
    
    //start and stop points to be used in the substring function
    var c1,c2;
    
    switch (dailyhourly){
        case "daily":
            [c1,c2] = [8,10];
            break;
        case "hourly":
            [c1,c2] = [11,13];
            break;
    }
    
    var temp = parseInt(time_array[0].substring(c1,c2));
    var avg = 0;
    var count = 0;
    
    for(var i in time_array){
        if ((parseInt(time_array[i].substring(c1,c2)) == temp) && (i < time_array.length - 1)){
            avg += parseInt(pm25_array[i]);
            ++count;
        }
        else{
            avg /= count;
            
            pm25_avg_array.push(parseInt(avg));
            avg_time_array.push(time_array[i-1]);
            
            temp = parseInt(time_array[i].substring(c1,c2));
            avg = parseInt(pm25_array[i]);
            count = 0;
        }
    }
    
    return [avg_time_array, pm25_avg_array];
}

function clean_labels(time_arr){
    var cleaned_labels = [];
    
    for (i=0; i<time_arr.length; i++){
        cleaned_labels[i] = time_arr[i].substring(5,7) + "-" + time_arr[i].substring(8,10);
    }
    
    return cleaned_labels;
}





