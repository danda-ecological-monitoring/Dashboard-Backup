//setting up empty arrays 
var time_array = [];
var day_array = [];
var hour_array = [];

var pm25_array = [];
var pm25_daily_array = [];
var pm25_hourly_array = [];

//gets the data echoed by PHP
var div = document.getElementById("dom-target");
var json_data = JSON.parse(div.textContent);

//separates the raw JSON data into 2 arrays
for(var i in json_data){
	time_array.push(json_data[i][0]);
	pm25_array.push(parseInt(json_data[i][1]));
}

console.log(time_array);
console.log(pm25_array);

//daily average
//sets temp to the portion of each timestamp that corresponds to the 2 digit day value, ie "substring(5,7)" grabs the 6th and 7th characters from the timestamp string
var temp = parseInt(time_array[0].substring(5,7));
//average and count both initially 0
var avg = 0;
var count = 0;

//loops through every data point
for(var i in time_array){
    //checks to see that the ith day value matches what's stored in temp, and that the ith value is not the last value in the array
    if ((parseInt(time_array[i].substring(5,7)) == temp) && (i < time_array.length - 1)){
        //adds the ith value to the average
        avg += parseInt(pm25_array[i]);
        //increments the count
        ++count;
    }
    else{
        //as soon as the above if conditions no longer true, calcs average by dividing avg by count
        avg /= count;
        
        //adds the average to the daily pm25 array
        pm25_daily_array.push(parseInt(avg));
        //adds the corresponding timestamp to the day array
        day_array.push(time_array[i-1]);
        
        //starts calcualting the average for the next day value, ie temp is the day that is currently being looked at. Once a new day is reached, temp changes.
        temp = parseInt(time_array[i].substring(5,7));
        avg = parseInt(pm25_array[i]);
        count = 0;
    }
}

//hourly average
var temp = parseInt(time_array[0].substring(11,13));
var avg = 0;
var count = 0;

for(var i in time_array){
    if ((parseInt(time_array[i].substring(11,13)) == temp) && (i < time_array.length - 1)){
        avg += parseInt(pm25_array[i]);
        ++count;
    }
    else{
        avg /= count;
        
        pm25_hourly_array.push(parseInt(avg));
        hour_array.push(time_array[i-1]);
        
        temp = parseInt(time_array[i].substring(11,13));
        avg = parseInt(pm25_array[i]);
        count = 0;
    }
}

console.log(hour_array);
console.log(pm25_hourly_array);

//graph of the daily average
var ctx1 = document.getElementById("mychart1").getContext('2d');
var mychart1 = new Chart(ctx1, {
    type: 'line',
    data: {
        labels: day_array,
        datasets: [
        	{
            label: 'DailyPM25',
            data: pm25_daily_array,
            backgroundColor: 'rgba(56,160,51,0)',
            borderColor: 'rgba(56,160,51,1)',
            borderWidth: 3
            }]
    },
    options: {
        legend: {
            position: 'right',
            display: false
        },
        elements: {
            point:{
                radius: 0
            }
        },
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }],
            xAxes: [{
                gridLines: {
                    display: false
                }
            }]
        }
    }
});

//graph of the hourly average
var ctx2 = document.getElementById("mychart2").getContext('2d');
var mychart2 = new Chart(ctx2, {
    type: 'line',
    data: {
        labels: hour_array,
        datasets: [
        	{
            label: 'HourlyPM25',
            data: pm25_hourly_array,
            backgroundColor: 'rgba(56,160,51,0)',
            borderColor: 'rgba(229,25,25,1)',
            borderWidth: 3
        	}]
    },
    options: {
        legend: {
            position: 'right',
            display: false
        },
        elements: {
            point:{
                radius: 0
            }
        },
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }],
            xAxes: [{
                gridLines: {
                    display: false
                }
            }]
        }
    }
});

//graph of the raw data
var ctx3 = document.getElementById("mychart3").getContext('2d');
var mychart3 = new Chart(ctx3, {
    type: 'line',
    data: {
        labels: time_array,
        datasets: [
        	{
            label: 'DailyPM25',
            data: pm25_array,
            backgroundColor: 'rgba(56,160,51,0)',
            borderColor: 'rgba(244,170,66,1)',
            borderWidth: 3
        	}]
    },
    options: {
        legend: {
            position: 'right',
            display: false
        },
        elements: {
            point:{
                radius: 0
            }
        },
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }],
            xAxes: [{
                gridLines: {
                    display: false
                }
            }]
        }
    }
});
