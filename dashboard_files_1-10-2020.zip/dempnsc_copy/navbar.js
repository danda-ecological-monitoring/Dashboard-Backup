//This loads the contents of navbar.html into the nav-placeholder div tag. Then it adds the "active" class to whichever navbar link has an id which matches the value given in the data-active field of the nav-placeholder div tag.
$(document).ready(function() {
    $("#nav-placeholder").load("navbar.html", function(){
        var active_tab = document.getElementById("nav-placeholder").dataset.active;
        document.getElementById(active_tab).classList.add("active");
        
        //uses a smaller logo on page load if display width is less than 1000
        if (window.innerWidth > 999) {
            document.getElementById("logo-image").src = "assets/images/dashboard_logo_5_3016_313.png";
        }
        else{
            document.getElementById("logo-image").src = "assets/images/dashboard_logo_315_1740.png";
            document.getElementsByClassName("dropdown-toggle")[0].classList.add("btn");
        }
    });
});

//switches to the smaller logo on resize as well
window.onresize = function() {
    if (window.innerWidth > 999) {
        document.getElementById("logo-image").src = "assets/images/dashboard_logo_5_3016_313.png";
        
        //removes btn class, since causes problems in traditional tab view
        document.getElementsByClassName("dropdown-toggle")[0].classList.remove("btn");
    }
    else{
        document.getElementById("logo-image").src = "assets/images/dashboard_logo_315_1740.png";
        
        //adds btn class so outline/box-shadow doesn't appear when focused
        document.getElementsByClassName("dropdown-toggle")[0].classList.add("btn");
    }
}

//This prevents the outline from appearing during/after any buttons with the "btn" class are clicked (mostly the navbar-toggler)
$(".btn").mousedown(function(e){
    e.preventDefault();
});