$(document).ready(function() {
    $("#sensor-content-1").load("sensor_content1.html", function(){
        var site_name = document.getElementById("sensor-content-1").dataset.site;
        document.getElementById("breadcrumb-active").textContent = site_name;
    });
});

$(document).ready(function() {
    $("#sensor-content-2").load("sensor_content2.html");
});