//This loads the footer into the div tags with id "footer-placeholder"
$(document).ready(function() {
    $("#footer-placeholder").load("footer.html");
});